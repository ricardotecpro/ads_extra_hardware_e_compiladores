---
layout: aula
title: Aula 01 – Introdução à Computação e Bases Numéricas
date: 2026-02-16
quiz: quiz-01
exercicios: exercicio-01
projeto: projeto-01
slides: slides-01.html
---

## 🎯 Objetivos de Aprendizagem

* Compreender o conceito de computação.
* Entender a necessidade de diferentes bases numéricas.
* Diferenciar sistema decimal, binário, octal e hexadecimal.

## 📘 Conteúdo

### O que é Computação?
A computação é a ciência que estuda o processamento automático de informações. Ela envolve o desenvolvimento de algoritmos e o uso de máquinas (computadores) para resolver problemas.

### Por que Bases Numéricas?
Nós humanos usamos o sistema **decimal** (base 10) porque temos 10 dedos. Computadores, no entanto, funcionam com eletricidade, que tem dois estados básicos: ligado e desligado. Por isso, o sistema **binário** (base 2) é natural para eles.

Existem outras bases úteis na computação:
* **Octal (Base 8)**: Agrupa 3 bits.
* **Hexadecimal (Base 16)**: Agrupa 4 bits, muito usado para representar cores e endereços de memória.

## 💡 Exemplo Prático

No sistema decimal, o número 157 significa:
$$ 1 \times 100 + 5 \times 10 + 7 \times 1 $$

No sistema binário, o número 101 significa:
$$ 1 \times 4 + 0 \times 2 + 1 \times 1 = 5 \text{ (em decimal)} $$

## ⚠️ Erros Comuns
* **Confundir valor com representação**: O número "cinco" é uma quantidade. "5" é a representação decimal, "101" é a representação binária, mas a quantidade é a mesma.

## 📝 Resumo
* Computadores usam binário (0 e 1).
* Cada base numérica tem suas regras de posição e valor.

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-02)
