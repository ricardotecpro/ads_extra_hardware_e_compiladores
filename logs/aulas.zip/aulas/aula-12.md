---
layout: aula
title: Aula 12 – Tipos de Mídia e Sistemas Multimídia
date: 2026-02-16
quiz: quiz-12
exercicios: exercicio-12
projeto: projeto-12
slides: slides-12.html
---

## 🎯 Objetivos de Aprendizagem

* Definir multimídia.
* Classificar tipos de mídia (estática vs. dinâmica).
* Entender a interação humano-computador através da multimídia.

## 📘 Conteúdo

### O que é Multimídia?
É a combinação de diferentes tipos de conteúdo (texto, áudio, vídeo, animação, imagem) para transmitir informação ou entreter.
Um sistema é considerado multimídia quando permite ao usuário navegar, interagir, criar e se comunicar com esse conteúdo.

### Tipos de Mídia

1. **Mídia Estática (Discreta)**: Não muda com o tempo.
   - Texto, Imagem, Gráficos.
2. **Mídia Dinâmica (Contínua)**: Depende do tempo para existir.
   - Áudio, Vídeo, Animação.

### Hipermídia
Quando a multimídia permite navegação não linear (links), chamamos de Hipermídia. A World Wide Web é o maior exemplo de sistema hipermídia.

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-13)
