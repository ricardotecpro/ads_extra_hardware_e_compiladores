---
layout: aula
title: Aula 10 – Engenharia de Software
date: 2026-02-16
quiz: quiz-10
exercicios: exercicio-10
projeto: projeto-10
slides: slides-10.html
---

## 🎯 Objetivos de Aprendizagem

* Compreender o ciclo de vida do desenvolvimento de software (SDLC).
* Conhecer modelos de processo (Cascata vs. Ágil).
* Entender a importância de requisitos, testes e manutenção.

## 📘 Conteúdo

### O que é Engenharia de Software?
É a aplicação de uma abordagem sistemática, disciplinada e quantificável ao desenvolvimento, operação e manutenção de software.

### Ciclo de Vida do Software (SDLC)

1. **Levantamento de Requisitos**: Entender o que o cliente precisa. (A fase mais crítica!).
2. **Análise e Design**: Planejar como o sistema será construído (Arquitetura, Banco de Dados, UI).
3. **Implementação (Codificação)**: Escrever o código.
4. **Testes**: Verificar se o software faz o que deveria e encontrar bugs.
5. **Implantação (Deploy)**: Colocar o sistema em produção para o usuário.
6. **Manutenção**: Corrigir falhas e adicionar novas funcionalidades.

### Modelos de Processo

* **Cascata (Waterfall)**: Modelo linear e sequencial. Uma fase só começa quando a anterior termina. Rígido.
* **Ágil (Agile)**: Desenvolvimento iterativo e incremental. Entrega de valor contínua. Flexível a mudanças (Scrum, Kanban).

## 💡 Dica
"Se você falhar em planejar, está planejando falhar." A maioria dos projetos de software falha não por código ruim, mas por requisitos mal compreendidos.

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-11)
