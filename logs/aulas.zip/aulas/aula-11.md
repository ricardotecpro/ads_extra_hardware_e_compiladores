---
layout: aula
title: Aula 11 – Banco de Dados
date: 2026-02-16
quiz: quiz-11
exercicios: exercicio-11
projeto: projeto-11
slides: slides-11.html
---

## 🎯 Objetivos de Aprendizagem

* Compreender o conceito de Banco de Dados (BD) e SGBD.
* Entender a estrutura básica de Tabelas, Registros e Campos.
* Diferenciar Dados de Informação.

## 📘 Conteúdo

### Dados vs. Informação

* **Dado**: Fato bruto, sem contexto. (Ex: "25", "Vermelho").
* **Informação**: Dado processado, organizado e com significado. (Ex: "Idade: 25 anos", "Cor do carro: Vermelho").

### O que é um Banco de Dados?
Uma coleção organizada de dados, geralmente armazenados eletronicamente.

### SGBD (Sistema Gerenciador de Banco de Dados)
O software que permite criar, manter e controlar o acesso ao banco de dados (MySQL, PostgreSQL, Oracle, SQLite).

### Estrutura (Modelo Relacional)
É o modelo mais comum, baseado em tabelas.

* **Tabela (Entidade)**: Conjunto de dados sobre um tema (ex: Alunos).
* **Campo (Atributo/Coluna)**: Uma característica (ex: Nome, Idade, Matrícula).
* **Registro (Tupla/Linha)**: Uma instância única (ex: Aluno João, 20 anos, mat 123).
* **Chave Primária (PK)**: Identificador único de um registro (ex: CPF, ID).

## 💡 Exemplo

**Tabela: Produtos**

| ID (PK) | Nome | Preço |
|---|---|---|
| 1 | Notebook | 2500.00 |
| 2 | Mouse | 50.00 |
| 3 | Teclado | 100.00 |

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-12)
