---
layout: aula
title: Aula 06 – Regras de Fixação + Revisão Geral
date: 2026-02-16
quiz: quiz-06
exercicios: exercicio-06
projeto: projeto-06
slides: slides-06.html
---

## 🎯 Objetivos de Aprendizagem

* Consolidar o conhecimento sobre conversões de bases.
* Praticar com exercícios mistos.
* Resolver dúvidas comuns.

## 📘 Conteúdo

### Resumo das Regras

1. **Decimal para Qualquer Base**: Divisões sucessivas pela base de destino.
2. **Qualquer Base para Decimal**: Soma ponderada (Notação Posicional).
3. **Binário $\leftrightarrow$ Octal**: Agrupar de 3 em 3 bits.
4. **Binário $\leftrightarrow$ Hexadecimal**: Agrupar de 4 em 4 bits.

### Tabela de Referência Rápida

| Binário (3 bits) | Octal | Binário (4 bits) | Hex |
|---|---|---|---|
| 000 | 0 | 0000 | 0 |
| 001 | 1 | ... | ... |
| 010 | 2 | 1010 | A |
| 011 | 3 | 1111 | F |

### Exercícios de Fixação (Em Sala)

1. Converta **2024 (Decimal)** para Hexadecimal.
2. Converta **ACE (Hex)** para Binário.
3. Converta **101010 (Binário)** para Decimal.

## 💡 Dica de Mestre
Para converter Hex direto para Octal, o jeito mais fácil é passar por Binário no meio do caminho!
Hex $\rightarrow$ Binário $\rightarrow$ Octal.

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-07)
