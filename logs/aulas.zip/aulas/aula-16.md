---
layout: aula
title: Aula 16 – Estruturas de Controle e Tipos Estruturados
date: 2026-02-16
quiz: quiz-16
exercicios: exercicio-16
projeto: projeto-16
slides: slides-16.html
---

## 🎯 Objetivos de Aprendizagem

* Entender Estruturas de Decisão (Se/Senão).
* Entender Estruturas de Repetição (Loop).
* Introdução a Vetores (Listas).

## 📘 Conteúdo

### Estruturas de Decisão (Condicionais)
Permitem que o programa escolha caminhos diferentes baseado em uma condição.

```pseudocode
SE (nota >= 7) ENTÃO
    ESCREVA "Aprovado"
SENÃO
    ESCREVA "Reprovado"
FIM_SE
```

### Estruturas de Repetição (Loops)
Permitem executar o mesmo bloco de código várias vezes.

```pseudocode
PARA i DE 1 ATÉ 10 FAÇA
    ESCREVA i
FIM_PARA
```

### Vetores (Arrays)
Uma variável que guarda vários valores do mesmo tipo. Como uma lista de chamada.
`notas = [8.5, 9.0, 7.5]`

## 📝 Conclusão do Curso
Chegamos ao fim da disciplina "Fundamentos da Computação".
Vimos desde o bit (0 e 1) até a lógica que permite criar softwares complexos.
O próximo passo é aprender uma linguagem de programação real (como Python, Java ou C)!

---
[Voltar ao Início]({{ site.baseurl }}/)
