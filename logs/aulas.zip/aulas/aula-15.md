---
layout: aula
title: Aula 15 – Fundamentos de Lógica e Comandos Básicos
date: 2026-02-16
quiz: quiz-15
exercicios: exercicio-15
projeto: projeto-15
slides: slides-15.html
---

## 🎯 Objetivos de Aprendizagem

* Compreender o que é um Algoritmo.
* Entender o fluxo de Entrada, Processamento e Saída.
* Conhecer ferramentas para desenhar lógica (Fluxogramas).

## 📘 Conteúdo

### O que é um Algoritmo?
É uma sequência finita de passos bem definidos para resolver um problema.
Exemplo: Receita de bolo, trocar pneu, manual de instruções.

### Componentes de um Programa

Todo programa de computador segue este ciclo básico:

1. **Entrada (Input)**: Dados que o programa recebe (Teclado, Arquivo, Sensor).
2. **Processamento**: O cálculo ou lógica aplicada aos dados.
3. **Saída (Output)**: O resultado mostrado ou salvo (Tela, Impressora, Arquivo).

### Exemplo em Pseudocódigo

```pseudocode
INÍCIO
    ESCREVA "Digite seu nome:"
    LEIA nome
    ESCREVA "Olá, " + nome
FIM
```

### Variáveis
São espaços na memória para guardar dados temporariamente.
Imagine uma caixa etiquetada onde você guarda um valor.

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-16)
