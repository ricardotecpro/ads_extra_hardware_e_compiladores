---
layout: aula
title: Aula 08 – Software e suas Categorias
date: 2026-02-16
quiz: quiz-08
exercicios: exercicio-08
projeto: projeto-08
slides: slides-08.html
---

## 🎯 Objetivos de Aprendizagem

* Definir o que é software.
* Classificar softwares em categorias: Sistema, Aplicativo e Utilitário.
* Reconhecer exemplos comuns de cada tipo.

## 📘 Conteúdo

### O que é Software?
Software é a parte lógica do computador. É o conjunto de instruções, dados e programas que dizem ao hardware o que fazer. Se o Hardware é o corpo (o que você chuta), o Software é a mente (o que você xinga).

### Categorias de Software

1. **Software de Sistema**:
   - Fornece a plataforma para outros softwares.
   - Ex: **Sistemas Operacionais** (Windows, Linux, macOS, Android), Drivers de dispositivos.

2. **Software de Aplicação (Aplicativos)**:
   - Realiza tarefas específicas para o usuário final.
   - Ex: Processadores de texto (Word), Navegadores (Chrome), Jogos, Editores de imagem.

3. **Software de Programação (Ferramentas de Desenvolvimento)**:
   - Usado por programadores para criar outros softwares.
   - Ex: Compiladores, Editores de código (VS Code), Depuradores.

4. **Malwares (Software Malicioso)**:
   - Softwares criados para causar danos. Vírus, worms, trojans.

### Código Aberto vs. Proprietário
- **Proprietário**: Código fechado, pertence a uma empresa, geralmente pago (Windows, Photoshop).
- **Open Source**: Código aberto, livre para modificar e distribuir (Linux, Firefox, Python).

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-09)
