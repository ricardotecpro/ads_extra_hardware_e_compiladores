---
layout: aula
title: Aula 07 – Arquitetura de Computadores
date: 2026-02-16
quiz: quiz-07
exercicios: exercicio-07
projeto: projeto-07
slides: slides-07.html
---

## 🎯 Objetivos de Aprendizagem

* Entender como o computador funciona internamente (Modelo de Von Neumann).
* Identificar os principais componentes de hardware.

## 📘 Conteúdo

### O Modelo de Von Neumann
Quase todos os computadores modernos seguem a arquitetura proposta por John von Neumann em 1945. Ela descreve um computador com:

1. **Unidade Central de Processamento (CPU)**: O "cérebro". Contém a Unidade Lógica e Aritmética (ULA) e a Unidade de Controle.
2. **Memória**: Onde dados e instruções são armazenados.
3. **Dispositivos de Entrada e Saída (E/S)**: A forma como o computador interage com o mundo (Teclado, Monitor, Mouse).
4. **Barramento (Bus)**: O sistema de comunicação que conecta tudo.

### Componentes Chave

* **CPU**: Executa instruções. Medida em GHz (bilhões de ciclos por segundo).
* **RAM (Random Access Memory)**: Memória volátil (apaga quando desliga). Rápida, usada para programas em execução.
* **Armazenamento (HDD/SSD)**: Memória não-volátil (permanente). Mais lenta que a RAM, mas armazena arquivos e o SO.
* **Placa-mãe**: A placa de circuito principal que conecta todos os componentes.

## 💡 Curiosidade
O primeiro computador eletrônico, o ENIAC, pesava 30 toneladas e ocupava 180m². Hoje, seu smartphone é milhões de vezes mais poderoso e cabe no bolso.

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-08)
