---
layout: aula
title: Aula 09 – Redes de Computadores
date: 2026-02-16
quiz: quiz-09
exercicios: exercicio-09
projeto: projeto-09
slides: slides-09.html
---

## 🎯 Objetivos de Aprendizagem

* Compreender o conceito de rede.
* Diferenciar LAN, WAN e Internet.
* Entender o modelo Cliente-Servidor.

## 📘 Conteúdo

### O que é uma Rede?
Uma rede de computadores são dois ou mais dispositivos conectados para compartilhar recursos (arquivos, impressoras, internet).

### Tipos de Redes (por abrangência)

* **LAN (Local Area Network)**: Rede Local. Restrita a um local geográfico pequeno, como uma casa, escritório ou prédio. Geralmente rápida.
* **WAN (Wide Area Network)**: Rede de Longa Distância. Conecta LANs distantes. A Internet é a maior WAN do mundo.
* **WLAN**: Wireless LAN (Rede Local Sem Fio/Wi-Fi).

### Como a Internet Funciona?

A Internet é uma "rede de redes". Ela conecta bilhões de dispositivos usando protocolos padrão (TCP/IP).

* **Endereço IP**: O identificador único de cada dispositivo na rede (ex: 192.168.0.1).
* **Cliente-Servidor**:
  - **Cliente**: Quem pede algo (seu navegador pedindo uma página web).
  - **Servidor**: Quem atende e fornece o recurso (o computador do Google enviando a página).

## 💡 Dica
Quando você acessa um site, você é o **cliente**. O site está hospedado em um **servidor**. A **Internet** é o caminho entre vocês.

---
[Próxima Aula]({{ site.baseurl }}/aulas/aula-10)
